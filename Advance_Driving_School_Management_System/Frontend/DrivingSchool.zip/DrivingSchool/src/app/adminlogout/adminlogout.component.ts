import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminlogout',
  templateUrl: './adminlogout.component.html',
  styleUrls: ['./adminlogout.component.css']
})
export class AdminlogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
